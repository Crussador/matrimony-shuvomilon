<?php
session_start();
require_once("includes/basic_includes.php");
require_once("functions.php");
require_once("includes/dbconn.php");

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
	header("location:login.php?redirect=partner_preference.php");
	exit();
}

// Get logged-in user ID
$id = intval($_SESSION['user_id']);

// Handle form submission for updating partner preferences
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$agemin = $_POST['agemin'] ?? '';
	$agemax = $_POST['agemax'] ?? '';
	$maritalstatus = $_POST['maritalstatus'] ?? '';
	$complexion = $_POST['complexion'] ?? '';
	$height = $_POST['height'] ?? '';
	$diet = $_POST['diet'] ?? '';
	$religion = $_POST['religion'] ?? '';
	$caste = $_POST['caste'] ?? '';
	$subcaste = $_POST['subcaste'] ?? '';
	$mothertounge = $_POST['mothertounge'] ?? '';
	$education = $_POST['education'] ?? '';
	$occupation = $_POST['occupation'] ?? '';
	$country = $_POST['country'] ?? '';
	$descr = $_POST['descr'] ?? '';

	$stmt = $conn->prepare("
        UPDATE partnerprefs 
        SET 
            agemin = ?, 
            agemax = ?, 
            maritalstatus = ?, 
            complexion = ?, 
            height = ?, 
            diet = ?, 
            religion = ?, 
            caste = ?, 
            subcaste = ?, 
            mothertounge = ?, 
            education = ?, 
            occupation = ?, 
            country = ?, 
            descr = ?
        WHERE custId = ?
    ");
	if ($stmt === false) {
		die("Error preparing statement: " . $conn->error);
	}
	$stmt->bind_param(
		"iissssssssssssi",
		$agemin,
		$agemax,
		$maritalstatus,
		$complexion,
		$height,
		$diet,
		$religion,
		$caste,
		$subcaste,
		$mothertounge,
		$education,
		$occupation,
		$country,
		$descr,
		$id
	);
	if ($stmt->execute()) {
		echo "<script>alert('Preferences updated successfully!');</script>";
	} else {
		echo "<script>alert('Error updating preferences: " . $stmt->error . "');</script>";
	}
	$stmt->close();
}

// Fetch partner preferences
$stmt = $conn->prepare("SELECT * FROM partnerprefs WHERE custId = ?");
if ($stmt === false) {
	die("Error preparing SQL statement: " . $conn->error);
}
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
	$row = $result->fetch_assoc();
	$agemin = $row['agemin'] ?? '';
	$agemax = $row['agemax'] ?? '';
	$maritalstatus = $row['maritalstatus'] ?? '';
	$complexion = $row['complexion'] ?? '';
	$height = $row['height'] ?? '';
	$diet = $row['diet'] ?? '';
	$religion = $row['religion'] ?? '';
	$caste = $row['caste'] ?? '';
	$subcaste = $row['subcaste'] ?? '';
	$mothertounge = $row['mothertounge'] ?? '';
	$education = $row['education'] ?? '';
	$occupation = $row['occupation'] ?? '';
	$country = $row['country'] ?? '';
	$descr = $row['descr'] ?? '';
} else {
	$agemin = $agemax = $maritalstatus = $complexion = $height = $diet = $religion = $caste = $subcaste = $mothertounge = $education = $occupation = $country = $descr = '';
}
$stmt->close();
?>
<!DOCTYPE HTML>
<html>

<head>
	<title>Partner Preferences</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="css/bootstrap-3.1.1.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	<link href='//fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
	<link href='//fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
	<link href="css/font-awesome.css" rel="stylesheet">
</head>

<body>
	<!-- Navigation -->
	<?php include_once("includes/navigation.php"); ?>

	<div class="grid_3">
		<div class="container">
			<div class="breadcrumb1">
				<ul>
					<a href="index.php"><i class="fa fa-home home_1"></i></a>
					<span class="divider">&nbsp;|&nbsp;</span>
					<li class="current-page">Partner Preferences</li>
				</ul>
			</div>
			<div class="profile">
				<form action="" method="post">
					<h3>My Ideal Partner</h3>
					<div class="form-group">
						<label for="descr">Describe your ideal partner:</label>
						<textarea name="descr" rows="5"
							class="form-control"><?php echo htmlspecialchars($descr); ?></textarea>
					</div>
					<div class="form-group">
						<label for="agemin">Age Range:</label>
						<input type="number" name="agemin" value="<?php echo htmlspecialchars($agemin); ?>" min="18"
							max="99" class="form-control" placeholder="Min Age">
						to
						<input type="number" name="agemax" value="<?php echo htmlspecialchars($agemax); ?>" min="18"
							max="99" class="form-control" placeholder="Max Age">
					</div>
					<div class="form-group">
						<label for="maritalstatus">Marital Status:</label>
						<select name="maritalstatus" class="form-control">
							<option value="Single" <?php if ($maritalstatus == "Single")
								echo "selected"; ?>>Single
							</option>
							<option value="Married" <?php if ($maritalstatus == "Married")
								echo "selected"; ?>>Married
							</option>
							<option value="Divorced" <?php if ($maritalstatus == "Divorced")
								echo "selected"; ?>>Divorced
							</option>
							<option value="Widowed" <?php if ($maritalstatus == "Widowed")
								echo "selected"; ?>>Widowed
							</option>
						</select>
					</div>
					<div class="form-group">
						<label for="complexion">Complexion:</label>
						<select name="complexion" class="form-control">
							<option value="Fair" <?php if ($complexion == "Fair")
								echo "selected"; ?>>Fair</option>
							<option value="Dark" <?php if ($complexion == "Dark")
								echo "selected"; ?>>Dark</option>
							<option value="Wheatish" <?php if ($complexion == "Wheatish")
								echo "selected"; ?>>Wheatish
							</option>
						</select>
					</div>
					<div class="form-group">
						<label for="height">Height (in cm):</label>
						<input type="number" name="height" value="<?php echo htmlspecialchars($height); ?>" min="120"
							max="250" class="form-control" placeholder="Enter Height">
					</div>
					<div class="form-group">
						<label for="diet">Diet:</label>
						<select name="diet" class="form-control">
							<option value="Veg" <?php if ($diet == "Veg")
								echo "selected"; ?>>Veg</option>
							<option value="Non-Veg" <?php if ($diet == "Non-Veg")
								echo "selected"; ?>>Non-Veg</option>
						</select>
					</div>
					<div class="form-group">
						<label for="religion">Religion:</label>
						<select name="religion" class="form-control">
							<option value="Hindu" <?php if ($religion == "Hindu")
								echo "selected"; ?>>Hindu</option>
							<option value="Muslim" <?php if ($religion == "Muslim")
								echo "selected"; ?>>Muslim</option>
							<option value="Christian" <?php if ($religion == "Christian")
								echo "selected"; ?>>Christian
							</option>
							<option value="Sikh" <?php if ($religion == "Sikh")
								echo "selected"; ?>>Sikh</option>
							<option value="Jain" <?php if ($religion == "Jain")
								echo "selected"; ?>>Jain</option>
						</select>
					</div>
					<div class="form-group">
						<label for="caste">Caste:</label>
						<input type="text" name="caste" value="<?php echo htmlspecialchars($caste); ?>"
							class="form-control" placeholder="Enter Caste">
					</div>
					<div class="form-group">
						<label for="subcaste">Sub-Caste:</label>
						<input type="text" name="subcaste" value="<?php echo htmlspecialchars($subcaste); ?>"
							class="form-control" placeholder="Enter Sub-Caste">
					</div>
					<div class="form-group">
						<label for="mothertounge">Mother Tongue:</label>
						<input type="text" name="mothertounge" value="<?php echo htmlspecialchars($mothertounge); ?>"
							class="form-control" placeholder="Enter Mother Tongue">
					</div>
					<div class="form-group">
						<label for="education">Education:</label>
						<select name="education" class="form-control">
							<option value="Primary" <?php if ($education == "Primary")
								echo "selected"; ?>>Primary
							</option>
							<option value="High School" <?php if ($education == "High School")
								echo "selected"; ?>>High
								School</option>
							<option value="Graduate" <?php if ($education == "Graduate")
								echo "selected"; ?>>Graduate
							</option>
							<option value="Post Graduate" <?php if ($education == "Post Graduate")
								echo "selected"; ?>>
								Post Graduate</option>
							<option value="Doctorate" <?php if ($education == "Doctorate")
								echo "selected"; ?>>Doctorate
							</option>
						</select>
					</div>
					<div class="form-group">
						<label for="occupation">Occupation:</label>
						<input type="text" name="occupation" value="<?php echo htmlspecialchars($occupation); ?>"
							class="form-control" placeholder="Enter Occupation">
					</div>
					<div class="form-group">
						<label for="country">Country of Residence:</label>
						<input type="text" name="country" value="<?php echo htmlspecialchars($country); ?>"
							class="form-control" placeholder="Enter Country">
					</div>
					<input type="submit" value="Update Preferences" class="btn btn-primary">
				</form>
			</div>
		</div>
	</div>

	<?php include_once("footer.php"); ?>
</body>

</html>