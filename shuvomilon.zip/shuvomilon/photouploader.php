<?php
session_start();
require_once("includes/basic_includes.php");
require_once("includes/dbconn.php");
require_once("functions.php");

// Ensure $conn is properly initialized
if (!$conn) {
  die("Database connection failed: " . mysqli_connect_error());
}

// Get the user ID from URL or session
$id = $_GET['id'] ?? $_SESSION['user_id'];

// Validate user ID
if (empty($id)) {
  die("User ID is not set. Ensure the 'id' is passed in the URL.");
}

// Verify the user exists in the database
$sql = "SELECT id FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
if ($stmt) {
  $stmt->bind_param("i", $id);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($result->num_rows === 0) {
    die("Invalid user ID.");
  }
} else {
  die("Error preparing statement: " . $conn->error);
}

// Handle photo upload
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  uploadphoto($id);
}
?>
<!DOCTYPE HTML>
<html>

<head>
  <title>Upload Photos</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link href="css/bootstrap-3.1.1.min.css" rel="stylesheet" type="text/css" />
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link href="css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
  <!-- Navigation -->
  <?php include_once("includes/navigation.php"); ?>

  <div class="container" style="background-color: #fafafa; padding: 20px; border-radius: 10px;">
    <h2 style="color: #ff5722; font-family: 'Playfair Display', serif;">Upload Your Photos</h2>
    <form action="" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="pic1" style="color: #ff5722;">Photo 1:</label>
        <input type="file" name="pic1" required style="border-radius: 5px; padding: 5px; border: 1px solid #ff5722;">
      </div>
      <div class="form-group">
        <label for="pic2" style="color: #ff5722;">Photo 2:</label>
        <input type="file" name="pic2" style="border-radius: 5px; padding: 5px; border: 1px solid #ff5722;">
      </div>
      <div class="form-group">
        <label for="pic3" style="color: #ff5722;">Photo 3:</label>
        <input type="file" name="pic3" style="border-radius: 5px; padding: 5px; border: 1px solid #ff5722;">
      </div>
      <div class="form-group">
        <label for="pic4" style="color: #ff5722;">Photo 4:</label>
        <input type="file" name="pic4" style="border-radius: 5px; padding: 5px; border: 1px solid #ff5722;">
      </div>
      <input type="submit" value="Upload Photos" class="btn btn-primary"
        style="background-color: #ff5722; color: #fff; padding: 10px 20px; border-radius: 5px;">
    </form>
    <h2 style="color: #ff5722; font-family: 'Playfair Display', serif;">Pic 1 and Pic 2 have the Topmost priority for
      matchmaking.</h2>
    <h2 style="color: #ff5722; font-family: 'Playfair Display', serif;">So Update it accordingly</h2>
  </div>
  <?php include_once("footer.php"); ?>
</body>

</html>