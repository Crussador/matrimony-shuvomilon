<?php
session_start();
require_once 'includes/dbconn.php';

// Redirect if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("location:login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Initialize variables
$matches = [];
$preferences = [];

// Fetch the user's profile picture from the `photos` table
$sql_photo = "SELECT pic1 FROM photos WHERE cust_id = ?";
$stmt_photo = $conn->prepare($sql_photo);
if ($stmt_photo === false) {
    die("Error preparing photo query: " . $conn->error);
}
$stmt_photo->bind_param("i", $user_id);
$stmt_photo->execute();
$result_photo = $stmt_photo->get_result();
$user_photo = $result_photo->fetch_assoc()['pic1'] ?? null;

// Fetch the user's gender
$sql_user_gender = "SELECT gender FROM users WHERE id = ?";
$stmt_gender = $conn->prepare($sql_user_gender);
if ($stmt_gender === false) {
    die("Error preparing gender query: " . $conn->error);
}
$stmt_gender->bind_param("i", $user_id);
$stmt_gender->execute();
$result_gender = $stmt_gender->get_result();
$user_gender = $result_gender->fetch_assoc()['gender'] ?? null;

if (!$user_gender) {
    die("Could not fetch user's gender. Please ensure the user exists in the users table.");
}

// Fetch partner preferences
$sql_preferences = "SELECT * FROM partnerprefs WHERE custId = ?";
$stmt_preferences = $conn->prepare($sql_preferences);
if ($stmt_preferences === false) {
    die("Error preparing preferences query: " . $conn->error);
}
$stmt_preferences->bind_param("i", $user_id);
$stmt_preferences->execute();
$preferences = $stmt_preferences->get_result()->fetch_assoc();

if (!$preferences) {
    die("No preferences found. Please set your partner preferences.");
}

// Fetch potential matches
$sql_matches = "
    SELECT id, username AS name, 
           TIMESTAMPDIFF(YEAR, dateofbirth, CURDATE()) AS age, 
           gender 
    FROM users 
    WHERE gender != ? 
      AND TIMESTAMPDIFF(YEAR, dateofbirth, CURDATE()) BETWEEN ? AND ? 
      AND id != ?";
$stmt_matches = $conn->prepare($sql_matches);
if ($stmt_matches === false) {
    die("Error preparing matches query: " . $conn->error);
}

$preferred_gender = $user_gender === 'male' ? 'female' : 'male';
$agemin = $preferences['agemin'] ?? 18;
$agemax = $preferences['agemax'] ?? 50;

$stmt_matches->bind_param("siii", $preferred_gender, $agemin, $agemax, $user_id);
$stmt_matches->execute();
$result_matches = $stmt_matches->get_result();
while ($row = $result_matches->fetch_assoc()) {
    $matches[] = $row;
}
?>
<!DOCTYPE HTML>
<html>

<head>
    <title>Shuvomilon | User Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap-3.1.1.min.css" rel="stylesheet" type="text/css" />
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <link href='//fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
    <link href="css/font-awesome.css" rel="stylesheet">
    <style>
        .sidebar-wrapper {
            background-color: #FFFDD0;
            text-align: center;
            padding: 10px 0;
        }

        .profile-img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 15px;
            object-fit: cover;
        }

        .nav-item a {
            color: maroon;
            font-size: 15px;
        }

        .dropdown-menu {
            background-color: whitesmoke;
            border: none;
        }

        .dropdown-menu a {
            color: darkgoldenrod;
            font-size: 14px;
        }

        .content-area {
            padding: 20px;
        }

        .profile-card {
            border: 1px solid #ddd;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <?php include_once("includes/navigation.php"); ?>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="sidebar-wrapper">
                <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>
                <!-- Profile Picture -->
                <?php if ($user_photo): ?>
                    <img src="profile/<?php echo $user_id; ?>/<?php echo $user_photo; ?>" alt="Profile Picture"
                        class="profile-img">
                <?php else: ?>
                    <img src="default-profile.png" alt="Default Profile Picture" class="profile-img">
                <?php endif; ?>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="partner_preference.php?id=<?php echo $user_id; ?>">Partner
                            Preferences</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="photouploader.php?id=<?php echo $user_id; ?>">Upload Photo</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="create_profile.php?id=<?php echo $user_id; ?>">Update Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="view_profile.php?id=<?php echo $user_id; ?>">View Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search.php">Search Profiles</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content Area -->
    <div class="content-area">
        <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>

        <!-- Display Matches -->
        <h3>Potential Matches</h3>
        <?php if (count($matches) > 0): ?>
            <?php foreach ($matches as $match): ?>


                // Profile Image
                echo "<div style='flex: 1; max-width: 120px; margin-right: 20px;'>";
                    echo "<img src='{$photo}' alt='Profile Picture'
                        style='width: 100%; border-radius: 10px; object-fit: cover;'>";
                    echo "</div>";


                <div class="profile-card">
                    <img src="profile/<?php echo htmlspecialchars($match['id']); ?>/<?php echo htmlspecialchars($match['pic1'] ?? 'default-profile.png'); ?>"
                        alt="Profile Picture">
                    <div>
                        <h4><?php echo htmlspecialchars($match['name'] ?? 'Name not available'); ?></h4>
                        <p>Age: <?php echo htmlspecialchars($match['age'] ?? 'N/A'); ?></p>
                        <p>Gender: <?php echo htmlspecialchars($match['gender']); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No matches found. Update your <a href="partner_preference.php">partner preferences</a>.</p>
        <?php endif; ?>

        <!-- Display Partner Preferences -->
        <h3>Your Partner Preferences</h3>
        <div class="profile-card">
            <p><strong>Age Range:</strong> <?php echo htmlspecialchars($preferences['agemin'] ?? 'N/A'); ?> -
                <?php echo htmlspecialchars($preferences['agemax'] ?? 'N/A'); ?>
            </p>
            <p><strong>Religion:</strong> <?php echo htmlspecialchars($preferences['religion'] ?? 'N/A'); ?></p>
            <p><strong>Country:</strong> <?php echo htmlspecialchars($preferences['country'] ?? 'N/A'); ?></p>
        </div>
    </div>

    <?php include_once("footer.php"); ?>
</body>

</html>