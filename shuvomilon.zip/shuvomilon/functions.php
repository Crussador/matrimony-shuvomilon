<?php
function mysqlexec($sql)
{
	// Database credentials
	$host = "localhost"; // Host name
	$username = "root"; // Mysql username
	$password = ""; // Mysql password
	$db_name = "matrimony"; // Database name

	// Connect to the server and select the database
	$conn = mysqli_connect($host, $username, $password, $db_name);
	if (!$conn) {
		die("Database connection failed: " . mysqli_connect_error());
	}

	// Execute the query
	if ($result = mysqli_query($conn, $sql)) {
		return $result;
	} else {
		echo "SQL Error: " . mysqli_error($conn);
		return false;
	}
}

function searchid()
{
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$profid = $_POST['profid'];
		$sql = "SELECT * FROM customer WHERE id=$profid";
		$result = mysqlexec($sql);
		return $result;
	}
}

function search()
{
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$agemin = isset($_POST['agemin']) ? $_POST['agemin'] : null;
		$agemax = isset($_POST['agemax']) ? $_POST['agemax'] : null;
		$maritalstatus = isset($_POST['maritalstatus']) ? $_POST['maritalstatus'] : null;
		$country = isset($_POST['country']) ? $_POST['country'] : null;
		$state = isset($_POST['state']) ? $_POST['state'] : null;
		$religion = isset($_POST['religion']) ? $_POST['religion'] : null;
		$mothertounge = isset($_POST['mothertounge']) ? $_POST['mothertounge'] : null;
		$sex = isset($_POST['sex']) ? $_POST['sex'] : null;

		$sql = "SELECT * FROM customer WHERE 
            sex='$sex' 
            AND age>='$agemin'
            AND age<='$agemax'
            AND maritalstatus = '$maritalstatus'
            AND country = '$country'
            AND state = '$state'
            AND religion = '$religion'
            AND mothertounge = '$mothertounge'";

		$result = mysqlexec($sql);
		return $result;
	}
}

function writepartnerprefs($id)
{
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$agemin = isset($_POST['agemin']) ? $_POST['agemin'] : null;
		$agemax = isset($_POST['agemax']) ? $_POST['agemax'] : null;
		$maritalstatus = isset($_POST['maritalstatus']) ? $_POST['maritalstatus'] : null;
		$complexion = isset($_POST['colour']) ? $_POST['colour'] : null;
		$height = isset($_POST['height']) ? $_POST['height'] : null;
		$diet = isset($_POST['diet']) ? $_POST['diet'] : null;
		$religion = isset($_POST['religion']) ? $_POST['religion'] : null;
		$caste = isset($_POST['caste']) ? $_POST['caste'] : null;
		$mothertounge = isset($_POST['mothertounge']) ? $_POST['mothertounge'] : null;
		$education = isset($_POST['education']) ? $_POST['education'] : null;
		$occupation = isset($_POST['occupation']) ? $_POST['occupation'] : null;
		$country = isset($_POST['country']) ? $_POST['country'] : null;
		$descr = isset($_POST['descr']) ? $_POST['descr'] : null;

		$sql = "UPDATE partnerprefs 
                SET
                   agemin = '$agemin',
                   agemax = '$agemax',
                   maritalstatus = '$maritalstatus',
                   complexion = '$complexion',
                   height = '$height',
                   diet = '$diet',
                   religion = '$religion',
                   caste = '$caste',
                   mothertounge = '$mothertounge',
                   education = '$education',
                   descr = '$descr',
                   occupation = '$occupation',
                   country = '$country' 
                WHERE custId = '$id'";

		$result = mysqlexec($sql);
		if ($result) {
			echo "<script>alert(\"Successfully updated Partner Preference\")</script>";
			echo "<script> window.location=\"userhome.php?id=$id\"</script>";
		} else {
			echo "Error: Failed to update partner preferences.";
		}
	}
}

function register()
{
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$uname = isset($_POST['name']) ? $_POST['name'] : null;
		$pass = isset($_POST['pass']) ? $_POST['pass'] : null;
		$email = isset($_POST['email']) ? $_POST['email'] : null;
		$day = isset($_POST['day']) ? $_POST['day'] : null;
		$month = isset($_POST['month']) ? $_POST['month'] : null;
		$year = isset($_POST['year']) ? $_POST['year'] : null;
		$dob = "$year-$month-$day";
		$gender = isset($_POST['gender']) ? $_POST['gender'] : null;

		require_once("includes/dbconn.php");

		$sql = "INSERT INTO users (profilestat, username, password, email, dateofbirth, gender, userlevel) 
                VALUES (0, '$uname', '$pass', '$email', '$dob', '$gender', 0)";

		if (mysqlexec($sql)) {
			echo "<div style='text-align: center; margin-top: 20px;'>
                    <p>Successfully Registered</p>
                    <a href='login.php'>Login to your account</a>
                  </div>";
		} else {
			echo "Error: Failed to register user.";
		}
	}
}

function isloggedin()
{
	return isset($_SESSION['id']);
}

function processprofile_form($id)
{
	$conn = mysqli_connect("localhost", "root", "", "matrimony");
	if (!$conn) {
		die("Database connection failed: " . mysqli_connect_error());
	}

	$fields = [
		'fname',
		'lname',
		'sex',
		'email',
		'day',
		'month',
		'year',
		'religion',
		'caste',
		'subcaste',
		'country',
		'state',
		'district',
		'age',
		'maritalstatus',
		'profileby',
		'education',
		'edudescr',
		'bodytype',
		'physicalstatus',
		'drink',
		'smoke',
		'mothertounge',
		'bloodgroup',
		'weight',
		'height',
		'colour',
		'diet',
		'occupation',
		'occupationdescr',
		'fatheroccupation',
		'motheroccupation',
		'income',
		'bros',
		'sis',
		'aboutme'
	];

	$data = [];
	foreach ($fields as $field) {
		$data[$field] = isset($_POST[$field]) ? $_POST[$field] : null;
	}

	$dob = "{$data['year']}-{$data['month']}-{$data['day']}";

	$sql = "SELECT cust_id FROM customer WHERE cust_id=$id";
	$result = mysqlexec($sql);

	if (mysqli_num_rows($result) >= 1) {
		// Update profile
		$sql = "UPDATE customer 
                SET email = '{$data['email']}', age = '{$data['age']}', sex = '{$data['sex']}', 
                religion = '{$data['religion']}', caste = '{$data['caste']}', subcaste = '{$data['subcaste']}', 
                district = '{$data['district']}', state = '{$data['state']}', country = '{$data['country']}', 
                maritalstatus = '{$data['maritalstatus']}', profilecreatedby = '{$data['profileby']}', 
                education = '{$data['education']}', education_sub = '{$data['edudescr']}', 
                firstname = '{$data['fname']}', lastname = '{$data['lname']}', 
                body_type = '{$data['bodytype']}', physical_status = '{$data['physicalstatus']}', 
                drink = '{$data['drink']}', mothertounge = '{$data['mothertounge']}', colour = '{$data['colour']}', 
                weight = '{$data['weight']}', smoke = '{$data['smoke']}', dateofbirth = '$dob', 
                occupation = '{$data['occupation']}', occupation_descr = '{$data['occupationdescr']}', 
                annual_income = '{$data['income']}', fathers_occupation = '{$data['fatheroccupation']}', 
                mothers_occupation = '{$data['motheroccupation']}', no_bro = '{$data['bros']}', 
                no_sis = '{$data['sis']}', aboutme = '{$data['aboutme']}' 
                WHERE cust_id=$id";
		$result = mysqlexec($sql);
		if ($result) {
			echo "<script>alert(\"Successfully Updated Profile\")</script>";
			echo "<script> window.location=\"userhome.php?id=$id\"</script>";
		} else {
			echo "Error: Failed to update profile.";
		}
	} else {
		// Insert profile
		$sql = "INSERT INTO customer 
                (cust_id, email, age, sex, religion, caste, subcaste, district, state, country, maritalstatus, 
                profilecreatedby, education, education_sub, firstname, lastname, body_type, physical_status, drink, 
                mothertounge, colour, weight, height, blood_group, diet, smoke, dateofbirth, occupation, occupation_descr, 
                annual_income, fathers_occupation, mothers_occupation, no_bro, no_sis, aboutme, profilecreationdate) 
                VALUES 
                ('$id', '{$data['email']}', '{$data['age']}', '{$data['sex']}', '{$data['religion']}', 
                '{$data['caste']}', '{$data['subcaste']}', '{$data['district']}', '{$data['state']}', 
                '{$data['country']}', '{$data['maritalstatus']}', '{$data['profileby']}', '{$data['education']}', 
                '{$data['edudescr']}', '{$data['fname']}', '{$data['lname']}', '{$data['bodytype']}', 
                '{$data['physicalstatus']}', '{$data['drink']}', '{$data['mothertounge']}', '{$data['colour']}', 
                '{$data['weight']}', '{$data['height']}', '{$data['bloodgroup']}', '{$data['diet']}', 
                '{$data['smoke']}', '$dob', '{$data['occupation']}', '{$data['occupationdescr']}', 
                '{$data['income']}', '{$data['fatheroccupation']}', '{$data['motheroccupation']}', 
                '{$data['bros']}', '{$data['sis']}', '{$data['aboutme']}', CURDATE())";
		if (mysqlexec($sql)) {
			echo "Successfully Created Profile";
			echo "<a href=\"userhome.php?id={$id}\">Back to home</a>";
			$sql2 = "INSERT INTO partnerprefs (id, custId) VALUES('', '$id')";
			mysqlexec($sql2);
			$sql2 = "UPDATE users SET profilestat=1 WHERE id=$id";
			mysqlexec($sql2);
		} else {
			echo "Error: Failed to create profile.";
		}
	}
}

function uploadphoto($id)
{
	$target = "profile/" . $id . "/";
	if (!file_exists($target)) {
		mkdir($target, 0777, true);
	}

	$photos = ['pic1', 'pic2', 'pic3', 'pic4'];
	foreach ($photos as $photo) {
		if (!empty($_FILES[$photo]['tmp_name'])) {
			$targetPath = $target . basename($_FILES[$photo]['name']);
			move_uploaded_file($_FILES[$photo]['tmp_name'], $targetPath);
		}
	}

	$sql = "SELECT id FROM photos WHERE cust_id = '$id'";
	$result = mysqlexec($sql);
	$values = [];
	foreach ($photos as $photo) {
		$values[$photo] = isset($_FILES[$photo]['name']) ? $_FILES[$photo]['name'] : null;
	}

	if (mysqli_num_rows($result) == 0) {
		$sql = "INSERT INTO photos (cust_id, pic1, pic2, pic3, pic4) 
                VALUES ('$id', '{$values['pic1']}', '{$values['pic2']}', '{$values['pic3']}', '{$values['pic4']}')";
	} else {
		$sql = "UPDATE photos SET 
                pic1 = '{$values['pic1']}', 
                pic2 = '{$values['pic2']}', 
                pic3 = '{$values['pic3']}', 
                pic4 = '{$values['pic4']}' 
                WHERE cust_id = '$id'";
	}

	if (mysqlexec($sql)) {
		echo "Photo uploaded successfully!";
	} else {
		echo "Error in uploading photo.";
	}
}
?>