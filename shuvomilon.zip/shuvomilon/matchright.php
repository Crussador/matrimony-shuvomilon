<?php
// matchright.php
session_start(); // Ensure the session is started
require_once("includes/dbconn.php");

try {
    // Fetch the logged-in user's ID
    if (!isset($_SESSION['user_id'])) {
        throw new Exception("User not logged in.");
    }
    $user_id = $_SESSION['user_id'];

    // Fetch compatible matches based on user preferences
    $stmt = $pdo->prepare("
        SELECT c.*, p.pic1 
        FROM customer c
        LEFT JOIN photos p ON c.cust_id = p.cust_id
        WHERE c.sex != (SELECT sex FROM customer WHERE cust_id = :cust_id)
    ");
    $stmt->execute([':cust_id' => $user_id]);

    $matches = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Display matches
    if (count($matches) > 0) {
        echo "<div style='font-family: Arial, sans-serif; max-width: 800px; margin: auto;'>";

        foreach ($matches as $match) {
            $photo = !empty($match['pic1']) ? "profile/{$match['cust_id']}/{$match['pic1']}" : "default-profile.jpg"; // Use a default image if no photo available

            echo "<div style='border: 1px solid #ccc; padding: 15px; margin-bottom: 20px; border-radius: 10px; background-color: #f9f9f9;'>";
            echo "<div style='display: flex; align-items: center;'>";

            // Profile Image
            echo "<div style='flex: 1; max-width: 120px; margin-right: 20px;'>";
            echo "<img src='{$photo}' alt='Profile Picture' style='width: 100%; border-radius: 10px; object-fit: cover;'>";
            echo "</div>";

            // Profile Details
            echo "<div style='flex: 2;'>";
            echo "<h3 style='margin: 0; font-size: 1.5em; color: #333;'>{$match['firstname']} {$match['lastname']}</h3>";
            echo "<p style='margin: 5px 0; font-size: 1em; color: #555;'><strong>Age:</strong> " . date_diff(date_create($match['dateofbirth']), date_create('today'))->y . " Years</p>";
            echo "<p style='margin: 5px 0; font-size: 1em; color: #555;'><strong>Religion:</strong> {$match['religion']}</p>";
            echo "<p style='margin: 5px 0; font-size: 1em; color: #555;'><strong>Location:</strong> {$match['district']}, {$match['state']}, {$match['country']}</p>";
            echo "</div>";

            echo "</div>"; // End of flex container
            echo "</div>"; // End of match card
        }

        echo "</div>";
    } else {
        echo "<p style='font-family: Arial, sans-serif; text-align: center;'>No matches found.</p>";
    }
} catch (Exception $e) {
    echo "<p style='font-family: Arial, sans-serif; text-align: center; color: red;'>Error fetching matches: " . $e->getMessage() . "</p>";
}
?>