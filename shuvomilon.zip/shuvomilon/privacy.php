<?php include_once("includes/basic_includes.php"); ?>
<?php include_once("functions.php"); ?>

<!DOCTYPE HTML>
<html>

<head>
	<title>Find Your Perfect Partner - Make Love | Privacy Policy</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<script
		type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<link href="css/style.css" rel='stylesheet' type='text/css' />
	<link href='//fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
	<link href='//fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
	<link href="css/font-awesome.css" rel="stylesheet">
	<script>
		$(document).ready(function () {
			$(".dropdown").hover(
				function () {
					$('.dropdown-menu', this).stop(true, true).slideDown("fast");
					$(this).toggleClass('open');
				},
				function () {
					$('.dropdown-menu', this).stop(true, true).slideUp("fast");
					$(this).toggleClass('open');
				}
			);
		});
	</script>
</head>

<body>
	<!-- Navigation Start -->
	<?php include_once("includes/navigation.php"); ?>
	<!-- Navigation End -->
	<div class="grid_3">
		<div class="container">
			<div class="breadcrumb1">
				<ul>
					<a href="index.php"><i class="fa fa-home home_1"></i></a>
					<span class="divider">&nbsp;|&nbsp;</span>
					<li class="current-page">Privacy Policy</li>
				</ul>
			</div>
			<div class="terms_1">
				<h3>Privacy Policy</h3>
				<p>At Shuvomilon, your privacy is of utmost importance to us. This privacy policy explains how we
					collect,
					use, and protect your personal information to provide you with a safe and seamless matchmaking
					experience.</p>

				<h4>1. Information We Collect</h4>
				<ul class="feature_list">
					<li>Your personal details such as name, gender, date of birth, and contact information.</li>
					<li>Profile preferences including religion, marital status, and partner preferences.</li>
					<li>Photos and additional details to enhance your profile visibility.</li>
					<li>Activity data like login details, messages, and interactions with other users.</li>
				</ul>

				<h4>2. How We Use Your Information</h4>
				<ul class="feature_list">
					<li>To create your profile and recommend suitable matches based on your preferences.</li>
					<li>To facilitate communication with other members through secure messaging services.</li>
					<li>To improve our platform by analyzing user activity and preferences.</li>
					<li>To send you important updates, notifications, and promotional offers.</li>
				</ul>

				<h4>3. How We Protect Your Information</h4>
				<ul class="feature_list">
					<li>We implement industry-standard security measures to safeguard your data from unauthorized
						access.</li>
					<li>Access to your personal information is restricted to authorized personnel only.</li>
					<li>We regularly review our security protocols to ensure the highest level of data protection.</li>
				</ul>

				<h4>4. Sharing of Information</h4>
				<ul class="feature_list">
					<li>We do not sell or rent your personal information to third parties.</li>
					<li>Your profile details are shared only with other registered members to facilitate matchmaking.
					</li>
					<li>We may disclose your information if required by law or to protect our rights and the rights of
						our
						users.</li>
				</ul>

				<h4>5. Your Privacy Controls</h4>
				<ul class="feature_list">
					<li>You can update or delete your profile information at any time.</li>
					<li>Control who can view your profile and contact you through our privacy settings.</li>
					<li>Request the removal of your profile from our platform by contacting our support team.</li>
				</ul>

				<h4>6. Cookies and Tracking Technologies</h4>
				<ul class="feature_list">
					<li>We use cookies to enhance your browsing experience and provide personalized recommendations.
					</li>
					<li>You can manage your cookie preferences through your browser settings.</li>
				</ul>

				<h4>7. Changes to This Policy</h4>
				<p>We reserve the right to update this privacy policy at any time. Any changes will be posted on this
					page
					with a corresponding update date.</p>

				<h4>8. Contact Us</h4>
				<p>If you have any questions about this privacy policy or how your data is handled, please contact us at
					<a href="mailto:support@shuvomilon.com">support@shuvomilon.com</a>.
				</p>
			</div>
		</div>
	</div>

	<?php include_once("footer.php"); ?>
</body>

</html>