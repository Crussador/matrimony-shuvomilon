<?php
$host = "localhost"; // Host name
$username = "root"; // Mysql username
$password = ""; // Mysql password
$db_name = "matrimony"; // Database name

// Establish MySQLi connection
$conn = mysqli_connect($host, $username, $password, $db_name);

// Check MySQLi connection
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}

try {
	// Establish PDO connection
	$pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
	die("PDO Connection failed: " . $e->getMessage());
}
?>