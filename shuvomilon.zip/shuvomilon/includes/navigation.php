<?php
include_once("functions.php"); // Ensure this file contains the isloggedin() function
?>

<!DOCTYPE HTML>
<html>

<head>
    <style>
        /* Basic reset */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        /* Navbar styles */
        .navbar-inner {
            background-color: yellow;
            height: 60px;
            display: flex;
            align-items: center;
            padding: 0 20px;
        }

        .navbar-inner .brand img {
            height: 50px;
        }

        /* Toggle button styles */
        .navbar-toggle {
            background-color: transparent;
            color: maroon;
            border: none;
            font-size: 20px;
            cursor: pointer;
            display: none;
            /* Initially hidden */
        }

        .navbar-toggle .icon-bar {
            display: block;
            width: 22px;
            height: 2px;
            background-color: maroon;
            margin: 4px 0;
        }

        /* Horizontal navigation for large screens */
        .nav_bottom {
            background-color: yellow;
            overflow: hidden;
            width: 100%;
        }

        .nav_bottom .navbar-nav.nav_1 {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: flex-end;
        }

        .nav_bottom .navbar-nav.nav_1 li {
            display: inline-block;
            margin: 0 15px;
        }

        .nav_bottom .navbar-nav.nav_1 li a {
            color: maroon;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            padding: 10px 20px;
            display: block;
            transition: background-color 0.3s;
        }

        .nav_bottom .navbar-nav.nav_1 li a:hover {
            background-color: #ffc000;
            border-radius: 4px;
        }

        /* Side navigation menu for small screens */
        .side-nav {
            height: 100%;
            width: 0;
            position: fixed;
            top: 0;
            left: 0;
            background-color: yellow;
            overflow-x: hidden;
            transition: 0.3s;
            padding-top: 60px;
            z-index: 1000;
        }

        .side-nav ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .side-nav ul li a {
            padding: 10px 20px;
            text-decoration: none;
            font-size: 18px;
            color: maroon;
            display: block;
            transition: background-color 0.3s;
        }

        .side-nav ul li a:hover {
            background-color: #ffc000;
            color: #fff;
        }

        /* Open state for side navigation */
        .side-nav.open {
            width: 250px;
        }

        /* Close state for side navigation */
        .side-nav.closed {
            width: 0;
        }

        /* Media query for small screens */
        @media screen and (max-width: 768px) {
            .navbar-toggle {
                display: block;
            }

            .nav_bottom .navbar-nav.nav_1 {
                display: none;
            }

            .side-nav {
                display: block;
            }
        }

        /* Media query for large screens */
        @media screen and (min-width: 769px) {
            .side-nav {
                display: none;
            }
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <div class="navbar-inner">
        <a class="brand" href="index.php"><img src="images/head.png" alt="Shuvomilon"
                style="width: 220px; height: auto;"></a>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#side-menu">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
    </div>

    <!-- Horizontal Navbar -->
    <div class="nav_bottom">
        <ul class="navbar-nav nav_1">
            <li><a href="userhome.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact Us</a></li>
            <li><a href="login.php">Sign In</a></li>
        </ul>
    </div>

    <!-- Side Navigation -->
    <div id="side-menu" class="side-nav closed">
        <ul>
            <li><a href="userhome.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact Us</a></li>
            <li><a href="login.php">Sign In</a></li>
        </ul>
    </div>

    <!-- JavaScript to toggle side menu -->
    <script>
        document.querySelector('.navbar-toggle').addEventListener('click', function () {
            var sideMenu = document.getElementById("side-menu");
            if (sideMenu.classList.contains('open')) {
                sideMenu.classList.remove('open');
                sideMenu.classList.add('closed');
            } else {
                sideMenu.classList.remove('closed');
                sideMenu.classList.add('open');
            }
        });
    </script>
</body>

</html>