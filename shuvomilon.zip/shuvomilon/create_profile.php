<?php
include_once("includes/basic_includes.php");
include_once("functions.php");
require_once("includes/dbconn.php");

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}



// Fetch user ID from the session
if (isset($_SESSION['user_id'])) {
    $id = $_SESSION['user_id'];
} else {
    // Redirect if no user ID is set in the session

    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Process the form data
    processprofile_form($id);
}

?>
<!DOCTYPE HTML>
<html>

<head>
    <title>Create Your Profile - Shuvomilon</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8" />
    <link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' />
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/style.css" rel='stylesheet' />
    <link href='//fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet'>
    <link href='//fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet'>
    <link href="css/font-awesome.css" rel="stylesheet">
    <script>
        $(document).ready(function () {
            $(".dropdown").hover(function () {
                $('.dropdown-menu', this).stop(true, true).slideDown("fast");
                $(this).toggleClass('open');
            }, function () {
                $('.dropdown-menu', this).stop(true, true).slideUp("fast");
                $(this).toggleClass('open');
            });
        });
    </script>
</head>

<body>
    <?php include_once("includes/navigation.php"); ?>

    <div class="grid_3">
        <div class="container">
            <div class="breadcrumb1">
                <ul>
                    <a href="index.php">
                        <i class="fa fa-home home_1"></i>
                    </a>
                    <span class="divider">&nbsp;|&nbsp;</span>
                    <li class="current-page">Create Your Profile</li>
                </ul>
            </div>

            <div class="services">
                <div class="col-sm-12 login_left">
                    <form action="create_profile.php" method="POST">
                        <!-- Personal Details -->
                        <h3>Personal Details</h3>
                        <div class="form-group col-sm-6">
                            <label for="fname">First Name *</label>
                            <input type="text" id="fname" name="fname" required class="form-control" autofocus>
                        </div>
                        <div class="form-group col-sm-6">
                            <label for="lname">Last Name *</label>
                            <input type="text" id="lname" name="lname" required class="form-control">
                        </div>
                        <div class="form-group col-sm-6">
                            <label for="sex">Gender *</label>
                            <select name="sex" id="sex" class="form-control" required>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        <div class="form-group col-sm-6">
                            <label for="dob">Date of Birth *</label>
                            <input type="date" id="dob" name="dob" required class="form-control">
                        </div>

                        <!-- Contact Information -->
                        <h3>Contact Information</h3>
                        <div class="form-group col-sm-6">
                            <label for="email">Email *</label>
                            <input type="email" id="email" name="email" required class="form-control">
                        </div>
                        <div class="form-group col-sm-6">
                            <label for="phone">Phone Number *</label>
                            <input type="text" id="phone" name="phone" required class="form-control">
                        </div>

                        <!-- Address -->
                        <h3>Address</h3>
                        <div class="form-group col-sm-6">
                            <label for="country">Country *</label>
                            <select name="country" id="country" class="form-control" required>
                                <option value="India">India</option>
                                <option value="Bangladesh">Bangladesh</option>
                                <option value="USA">USA</option>
                                <option value="UK">UK</option>
                            </select>
                        </div>
                        <div class="form-group col-sm-6">
                            <label for="state">State *</label>
                            <input type="text" id="state" name="state" required class="form-control">
                        </div>
                        <div class="form-group col-sm-6">
                            <label for="city">City *</label>
                            <input type="text" id="city" name="city" required class="form-control">
                        </div>
                        <div class="form-group col-sm-6">
                            <label for="zip">Zip Code *</label>
                            <input type="text" id="zip" name="zip" required class="form-control">
                        </div>

                        <!-- Preferences -->
                        <h3>Preferences</h3>
                        <div class="form-group col-sm-6">
                            <label for="agemin">Preferred Age Min *</label>
                            <input type="number" id="agemin" name="agemin" required class="form-control">
                        </div>
                        <div class="form-group col-sm-6">
                            <label for="agemax">Preferred Age Max *</label>
                            <input type="number" id="agemax" name="agemax" required class="form-control">
                        </div>
                        <div class="form-group col-sm-6">
                            <label for="religion">Preferred Religion *</label>
                            <select name="religion" id="religion" class="form-control" required>
                                <option value="Hindu">Hindu</option>
                                <option value="Muslim">Muslim</option>
                                <option value="Christian">Christian</option>
                                <option value="Jain">Jain</option>
                                <option value="Sikh">Sikh</option>
                            </select>
                        </div>

                        <!-- Additional Details -->
                        <h3>Additional Details</h3>
                        <div class="form-group col-sm-6">
                            <label for="education">Education *</label>
                            <input type="text" id="education" name="education" required class="form-control">
                        </div>
                        <div class="form-group col-sm-6">
                            <label for="occupation">Occupation *</label>
                            <input type="text" id="occupation" name="occupation" required class="form-control">
                        </div>
                        <div class="form-group col-sm-6">
                            <label for="income">Annual Income *</label>
                            <input type="text" id="income" name="income" required class="form-control">
                        </div>

                        <!-- Submit Button -->
                        <div class="form-actions">
                            <button type="submit" href="userhome.php?id=<?php echo $user_id; ?> class=" btn
                                btn-primary">Update Profile</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php include_once("footer.php"); ?>
</body>

</html>