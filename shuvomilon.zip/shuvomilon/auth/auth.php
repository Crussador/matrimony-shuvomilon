<?php
session_start();
require_once('../includes/dbconn.php');

// Rate limiting to avoid brute force
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
}

function login($username, $password)
{
    global $conn;

    if ($_SESSION['login_attempts'] >= 5) {
        die("Too many login attempts. Try again later.");
    }

    // Fetch user from the database
    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ?");
    if (!$stmt) {
        die("Failed to prepare statement: " . $conn->error);
    }
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        // Compare plain text password (since it's unhashed)
        if ($password === $user['password']) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $username;
            $_SESSION['login_attempts'] = 0; // Reset attempts on successful login

            header("Location: ../userhome.php");
            exit();
        } else {
            $_SESSION['login_attempts']++;
            die("Invalid username or password.");
        }
    } else {
        die("No user found with the given username.");
    }
}

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    login($username, $password);
}
?>