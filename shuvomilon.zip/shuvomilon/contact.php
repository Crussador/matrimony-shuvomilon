<?php include_once("includes/navigation.php"); ?>
<?php
// contact.php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $message = htmlspecialchars(trim($_POST['message']));

    // Send email
    if (mail("support@shuvomilon.com", "Contact Form Submission", $message, "From: $email")) {
        $success_message = "Thank you for contacting us!";
    } else {
        $error_message = "There was an error sending your message. Please try again later.";
    }
}
?>

<!DOCTYPE HTML>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <title>Contact Us | Shuvomilon</title>
    <link rel="stylesheet" href="css/bootstrap-3.1.1.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }

        .contact-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background: #fff;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .form-control {
            border-radius: 5px;
        }

        .btn-custom {
            background-color: maroon;
            color: white;
            border-radius: 5px;
            padding: 10px 20px;
            transition: all 0.3s ease;
        }

        .btn-custom:hover {
            background-color: yellow;
            color: maroon;
        }

        .alert {
            margin-bottom: 20px;
        }

        .form-label {
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="contact-container">
            <h2 class="text-center" style="color: maroon;">Contact Us</h2>
            <p class="text-center">We'd love to hear from you! Please fill out the form below.</p>

            <?php if (isset($success_message)): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo $success_message; ?>
                </div>
            <?php elseif (isset($error_message)): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" id="name" name="name" class="form-control" placeholder="Your Name" required>
                </div>
                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="Your Email" required>
                </div>
                <div class="form-group">
                    <label for="message" class="form-label">Message</label>
                    <textarea id="message" name="message" class="form-control" rows="5" placeholder="Your Message"
                        required></textarea>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-custom">Send Message</button>
                </div>
            </form>
        </div>
    </div>
    <footer>
        <?php include_once("footer.php"); ?>
    </footer>
</body>

</html>