<?php include_once("includes/basic_includes.php"); ?>
<?php include_once("functions.php"); ?>

<!DOCTYPE HTML>
<html>

<head>
	<title>Aapka Jeevan Sathi - Shuvomilon | About :: Shuvomilon
	</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<script
		type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<!-- Custom Theme files -->
	<link href="css/style.css" rel='stylesheet' type='text/css' />
	<link href='//fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
	<link href='//fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
	<!----font-Awesome----->
	<link href="css/font-awesome.css" rel="stylesheet">
	<!----font-Awesome----->
	<script>
		$(document).ready(function () {
			$(".dropdown").hover(
				function () {
					$('.dropdown-menu', this).stop(true, true).slideDown("fast");
					$(this).toggleClass('open');
				},
				function () {
					$('.dropdown-menu', this).stop(true, true).slideUp("fast");
					$(this).toggleClass('open');
				}
			);
		});
	</script>
</head>

<body>
	<!-- ============================  Navigation Start =========================== -->
	<?php include_once("includes/navigation.php"); ?>
	<!-- ============================  Navigation End ============================ -->
	<div class="grid_3">
		<div class="container">
			<div class="breadcrumb1">
				<ul>
					<a href="index.php"><i class="fa fa-home home_1"></i></a>
					<span class="divider">&nbsp;|&nbsp;</span>
					<li class="current-page">About</li>
				</ul>
			</div>
			<div class="about">
				<div class="col-md-6 about_left">
					<img src="images/a3.jpg" class="img-responsive" alt="" />
				</div>
				<div class="col-md-6 about_right">
					<h1>About us</h1>
					<p>Greetings from Shuvomilon, your reliable marriage resource devoted to fostering relationships.
						Our goal is to make the process of finding the appropriate spouse as easy and fun as we can
						because we recognise that it is a big life journey.</p>
					<div class="accordation">
						<div class="jb-accordion-wrapper">
							<div class="jb-accordion-title">Why Us ? <button type="button" class="jb-accordion-button"
									data-toggle="collapse" data-target="#accordion-1-"><i class="fa fa-angle-down">
									</i></button></div>
							<p><!-- /.accordion-title -->
							</p>
							<div id="accordion-1-" class="jb-accordion-content collapse in" style="height: auto;">
								<p>We at Shuvomilon provide an easy-to-use platform that allows people to connect with
									one other based on common interests, values, and convictions. Our huge database is
									made to accommodate people from a variety of ethnicities and backgrounds, so
									everyone may discover their ideal match.</p>
							</div>
							<p><!-- /.collapse --></p>
						</div>
						<div class="jb-accordion-wrapper">
							<div class="jb-accordion-title">Assistance & Security <button type="button"
									class="jb-accordion-button" data-toggle="collapse" data-target="#accordion2-"><i
										class="fa fa-angle-down"> </i></button></div>
							<p><!-- /.accordion-title -->
							</p>
							<div id="accordion2-" class="jb-accordion-content collapse ">
								<p>We place a high value on your privacy and safety, taking strong precautions to
									safeguard your personal data while promoting sincere relationships. Our team is
									dedicated to offering top-notch assistance, assisting you at every turn as you start
									this thrilling new phase of your life.</p>
							</div>
							<p><!-- /.collapse --></p>
						</div>
						<div class="jb-accordion-wrapper">
							<div class="jb-accordion-title">Happy Begining !!!<button type="button"
									class="jb-accordion-button" data-toggle="collapse" data-target="#accordion3"><i
										class="fa fa-angle-down"> </i></button></div>
							<p><!-- /.accordion-title -->
							</p>
							<div id="accordion3" class="jb-accordion-content collapse ">
								<p>Visit us, and take the first step towards a beautiful journey of love and
									companionship.</p>
							</div>
							<p><!-- /.collapse --></p>
						</div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<div class="about_middle">
		<div class="container">
			<h2>Our Happy Members</h2>
			<div class="about_middle-grid1">
				<div class="col-sm-6 testi_grid list-item-0">
					<blockquote class="testi_grid_blockquote">
						<figure class="featured-thumbnail">
							<img src="images/a1.jpg" class="img-responsive" alt="" />
						</figure>
						<div><a href="#">"Shuvomilon connected us, and we never looked back. From strangers to
								soulmates, this journey has been magical."</a>
							<div class="clearfix"></div>
						</div>
					</blockquote>
					<small class="testi-meta"><span class="user">- Priya & Arjun</span></small>
				</div>
				<div class="col-sm-6 testi_grid list-item-1">
					<blockquote class="testi_grid_blockquote">
						<figure class="featured-thumbnail">
							<img src="images/a2.jpg" class="img-responsive" alt="" />
						</figure>
						<div><a href="#">"Thanks to Shuvomilon, I found my partner who perfectly complements me. Love
								truly finds its way!"</a>
							<div class="clearfix"></div>
						</div>
					</blockquote>
					<small class="testi-meta1"><span class="user">- Priya & Arjun</span></small>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="about_middle-grid2">
				<div class="col-sm-6 testi_grid list-item-0">
					<blockquote class="testi_grid_blockquote">
						<figure class="featured-thumbnail">
							<img src="images/a1.jpg" class="img-responsive" alt="" />
						</figure>
						<div><a href="#">"Finding love felt impossible until I joined Shuvomilon. It's not just a
								platform; it's a dream maker!"</a>
							<div class="clearfix"></div>
						</div>
					</blockquote>
					<small class="testi-meta"><span class="user">- Sameer & Anjali</span></small>
				</div>
				<div class="col-sm-6 testi_grid list-item-1">
					<blockquote class="testi_grid_blockquote">
						<figure class="featured-thumbnail">
							<img src="images/a2.jpg" class="img-responsive" alt="" />
						</figure>
						<div><a href="#">"Thanks to Shuvomilon, I found my partner who perfectly complements me. Love
								truly finds its way!"</a>
							<div class="clearfix"></div>
						</div>
					</blockquote>
					<small class="testi-meta1"><span class="user">- Sameer & Anjali </span></small>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<div class="about_bottom">
		<div class="container">
			<h3>Team</h3>
			<div class="col-md-3 about_grid1">
				<ul class="posts-grid our-team">
					<li class="list-item-1">
						<figure class="thumbnail_1 thumbnail">
							<a href="#"><img src="images/teamphoto/samratkar.jpg" class="img-responsive" alt="" /></a>
							<div class="post_networks">
								<ul>
									<li class="network_0"><a href="https://nugeniussolution.com/team.html" title=""><i
												class="fa fa-globe"></i></a></li>
								</ul>
							</div>
						</figure>
						<div class="desc">
							<h4><a href="https://nugeniussolution.com/team.html">Mr. Samrat Kar</a></h4>
							<p>"Our company is at the forefront of technological innovation, continually evolving to
								provide cutting-edge solutions that empower businesses and drive digital
								transformation."</p>
						</div>
					</li>
				</ul>
			</div>
			<div class="col-md-3 about_grid1">
				<ul class="posts-grid our-team">
					<li class="list-item-1">
						<figure class="thumbnail_1 thumbnail">
							<a href="#"><img src="images/teamphoto/sunitroy.jpg" class="img-responsive" alt="" /></a>
							<div class="post_networks">
								<ul>
									<li class="network_0"><a href="https://nugeniussolution.com/team.html" title=""><i
												class="fa fa-globe"></i></a></li>
								</ul>
							</div>
						</figure>
						<div class="desc">
							<h4><a href="https://nugeniussolution.com/team.html">Mr. Sunit Roy</a></h4>
							<p>Programming is learned by writing programs.</p>
						</div>
					</li>
				</ul>
			</div>
			<div class="col-md-3 about_grid1">
				<ul class="posts-grid our-team">
					<li class="list-item-1">
						<figure class="thumbnail_1 thumbnail">
							<a href="#"><img src="images/teamphoto/satrujitdev.jpg" class="img-responsive" alt="" /></a>
							<div class="post_networks">
								<ul>
									<li class="network_0"><a href="https://nugeniussolution.com/team.html" title=""><i
												class="fa fa-globe"></i></a></li>
								</ul>
							</div>
						</figure>
						<div class="desc">
							<h4><a href="https://nugeniussolution.com/team.html">Mr. Satrujit Dev</a></h4>
							<p>Software and cathedrals are much the same — first we build them, then we pray.</p>
						</div>
					</li>
				</ul>
			</div>


		</div>
	</div>


	<?php include_once("footer.php"); ?>