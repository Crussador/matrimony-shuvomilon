<?php include_once("includes/basic_includes.php");?>
<?php include_once("functions.php"); ?>

          
<?php

$id=$_GET['id'];
if(isloggedin()){
 //do nothing stay here
} else{
   header("location:login.php");
}


?>
<!DOCTYPE HTML>
<html>
<head>
<title>Shuvomilon
 | User Home :: Shuvomilon
</title>
<meta name="viewport" content="width=device-width, initial-scale=1 maximum-scale=1.0, user-scalable=no">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
<!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> -->
<!--font-Awesome-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--font-Awesome-->
<script>
$(document).ready(function(){
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');       
        }
    );
});
</script>
</head>
<body>
<!-- ============================  Navigation Start =========================== -->
  
<?php include_once("includes/navigation.php");?>
  
           
 
		 <!-- Brand and toggle get grouped for better mobile display -->

        
    <!-- Bootstrap CSS -->
    
    <style>
        .sidebar-wrapper {
            width: 150px;
            position: fixed;
            top: 50;
            left: 150;
            height: 80%;
            background-color: #FFFDD0;
            padding-top: 20px;
        }

        
        .sidebar-wrapper .navbar-toggler {
        display: none;
        background-color: transparent; /* Set background to transparent */
        color: maroon;
        margin: 10px;
        border: none;
        padding: 10px;
    }
        .sidebar-wrapper .nav-link {
            color: maroon;
            font-size: 15px;
            padding: 10px 20px;
            display: block;
        }

        .sidebar-wrapper .dropdown-menu {
        background-color: yellow;
        border: none;
        margin-left: 150px; /* Increased margin-left to open submenu on the right side */
        box-shadow: none;
        position: absolute; /* Added absolute positioning to ensure it opens to the right */
        top: 0; /* Align submenu with the parent menu item */
    }
        .sidebar-wrapper .dropdown-menu li a {
            color: maroon;
            font-size: 14px;
        }

        .sidebar-wrapper .nav-link:hover {
            background-color: none;
            color: #0056b3;
        }

        .sidebar-wrapper .dropdown-menu li a:hover {
            background-color: none;
            color: #0056b3;
        }

        @media (max-width: 768px) {
            .sidebar-wrapper {
                width: 100%;
                height: auto;
                position: relative;
            }
            .sidebar-wrapper .navbar-toggler {
                display: block;
            }
            .sidebar-wrapper .collapse {
                display: none;
            }
            .sidebar-wrapper .collapse.show {
                display: block;
                background-color: #FFFDD0;
                width: 100%;
                padding-top: 10px;
            }
            .sidebar-wrapper .nav-link {
                padding: 10px 15px;
            }
            .navbar-toggler {
    padding: 0;
  }
        }
    </style>
</head>
<body>

<div class="sidebar-wrapper">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidebar-menu" aria-controls="sidebar-menu" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon" style="background-color: none;">Click here</span>
  </button>
  
  <div class="collapse navbar-collapse" id="sidebar-menu">
    <ul class="nav flex-column">
      <li class="nav-item dropdown">
        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" style="font-size: 15px;">Profile<span class="caret"></span></a>
        <ul class="dropdown-menu" role="menu">
          <li><a href="create_profile.php?id=<?php echo $id;?>">Create Profile</a></li>
          <li><a href="create_profile.php?id=<?php echo $id;?>">Edit Profile</a></li>
          <li><a href="photouploader.php?id=<?php echo $id;?>">Upload Photos</a></li>
          <li><a href="view_profile.php?id=<?php echo $id;?>">View Profile</a></li>
        </ul>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="partner_preference.php?id=<?php echo $id;?>">Partner Matching Preference</a>
      </li>
      
      <li class="nav-item dropdown">
        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" style="font-size: 15px;">Search<span class="caret"></span></a>
        <ul class="dropdown-menu" role="menu">
          <li><a href="search.php">Regular Search</a></li>
          <li><a href="search-id.php">Search by ID</a></li>
          <li><a href="faq.php">Faq</a></li>
        </ul>
      </li>
    </ul>
  </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>





<div class="clearfix"> </div>

<?php include_once("footer.php")?>
<!-- FlexSlider -->
<script defer src="js/jquery.flexslider.js"></script>
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<script>
// Can also be used with $(document).ready()
$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide",
    controlNav: "thumbnails"
  });
});
</script>   
</body>

</html>
