<footer
    style="background-color: maroon; color: white; padding: 20px 0; text-align: center; margin-top: 30px; font-family: Arial, sans-serif;">
    <div style="max-width: 1200px; margin: 0 auto; display: flex; flex-wrap: wrap; justify-content: space-between;">
        <!-- About Us Section -->
        <div style="flex: 1; min-width: 250px; margin-bottom: 20px;">
            <h5 style="font-size: 18px; font-weight: bold; margin-bottom: 10px;">About Us</h5>
            <p style="line-height: 1.5; font-size: 14px;">
                Shuvomilon Matrimony is dedicated to connecting hearts and building beautiful relationships.
                Join us today to find your perfect partner.
            </p>
        </div>
        <!-- Quick Links Section -->
        <div style="flex: 1; min-width: 250px; margin-bottom: 20px;">
            <h5 style="font-size: 18px; font-weight: bold; margin-bottom: 10px;">Quick Links</h5>
            <ul style="list-style: none; padding: 0; font-size: 14px; line-height: 1.8;">
                <li><a href="index.php" style="color: yellow; text-decoration: none;">Home</a></li>
                <li><a href="contact.php" style="color: yellow; text-decoration: none;">Contact Us</a></li>
                <li><a href="about.php" style="color: yellow; text-decoration: none;">About Us</a></li>
                <li><a href="privacy.php" style="color: yellow; text-decoration: none;">Privacy Policy</a></li>
            </ul>
        </div>
        <!-- Social Media Section -->
        <div style="flex: 1; min-width: 250px; margin-bottom: 20px;">
            <h5 style="font-size: 18px; font-weight: bold; margin-bottom: 10px;">Follow Us</h5>
            <ul style="list-style: none; padding: 0; display: flex; justify-content: center; gap: 15px;">
                <li><a href="#" style="color: white; font-size: 20px; text-decoration: none;"><i
                            class="fa fa-facebook"></i></a></li>
                <li><a href="#" style="color: white; font-size: 20px; text-decoration: none;"><i
                            class="fa fa-twitter"></i></a></li>
                <li><a href="#" style="color: white; font-size: 20px; text-decoration: none;"><i
                            class="fa fa-instagram"></i></a></li>
            </ul>
        </div>
    </div>
    <hr style="border: 1px solid yellow; margin: 20px auto; width: 80%;">
    <p style="font-size: 14px; margin: 10px 0;">&copy; 2024 Shuvomilon Matrimony. All Rights Reserved.</p>
</footer>
<link rel="stylesheet" href="css/font-awesome.css">