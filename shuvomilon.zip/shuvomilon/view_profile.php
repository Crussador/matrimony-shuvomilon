<?php
include_once("includes/basic_includes.php");
include_once("functions.php");
require_once("includes/dbconn.php");

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
	header("location:login.php?redirect=view_profile.php");
	exit();
}

// Get the profile ID from the GET parameter and sanitize it
$profile_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetching profile details from the database
$sql = "SELECT * FROM customer WHERE cust_id = $profile_id";
$result = mysqlexec($sql);

if ($result && mysqli_num_rows($result) > 0) {
	$row = mysqli_fetch_assoc($result);

	// Extract profile details
	$fname = $row['firstname'];
	$lname = $row['lastname'];
	$sex = $row['sex'];
	$email = $row['email'];
	$dob = $row['dateofbirth'];
	$religion = $row['religion'];
	$caste = $row['caste'];
	$subcaste = $row['subcaste'];
	$country = $row['country'];
	$state = $row['state'];
	$district = $row['district'];
	$age = $row['age'];
	$maritalstatus = $row['maritalstatus'];
	$profileby = $row['profilecreatedby'];
	$education = $row['education'];
	$edudescr = $row['education_sub'];
	$bodytype = $row['body_type'];
	$physicalstatus = $row['physical_status'];
	$drink = $row['drink'];
	$smoke = $row['smoke'];
	$mothertounge = $row['mothertounge'];
	$bloodgroup = $row['blood_group'];
	$weight = $row['weight'];
	$height = $row['height'];
	$colour = $row['colour'];
	$diet = $row['diet'];
	$occupation = $row['occupation'];
	$occupationdescr = $row['occupation_descr'];
	$fatheroccupation = $row['fathers_occupation'];
	$motheroccupation = $row['mothers_occupation'];
	$income = $row['annual_income'];
	$bros = $row['no_bro'];
	$sis = $row['no_sis'];
	$aboutme = $row['aboutme'];
} else {
	echo "<script>alert('Invalid Profile ID');</script>";
	echo "<script>window.location='userhome.php';</script>";
	exit;
}

// Fetching image filenames from the database
$sql2 = "SELECT * FROM photos WHERE cust_id = $profile_id";
$result2 = mysqlexec($sql2);

$pic1 = $pic2 = $pic3 = $pic4 = ""; // Default values if no photos are found
if ($result2 && mysqli_num_rows($result2) > 0) {
	$row2 = mysqli_fetch_assoc($result2);
	$pic1 = $row2['pic1'];
	$pic2 = $row2['pic2'];
	$pic3 = $row2['pic3'];
	$pic4 = $row2['pic4'];
}

// Fetching partner preferences
$sql3 = "SELECT * FROM partnerprefs WHERE custId = $profile_id";
$result3 = mysqlexec($sql3);

if ($result3 && mysqli_num_rows($result3) > 0) {
	$row3 = mysqli_fetch_assoc($result3);
	$agemin = $row3['agemin'];
	$agemax = $row3['agemax'];
	$maritalstatus_pref = $row3['maritalstatus'];
	$complexion = $row3['complexion'];
	$height_pref = $row3['height'];
	$diet_pref = $row3['diet'];
	$religion_pref = $row3['religion'];
	$caste_pref = $row3['caste'];
	$mothertounge_pref = $row3['mothertounge'];
	$education_pref = $row3['education'];
	$occupation_pref = $row3['occupation'];
	$country_pref = $row3['country'];
	$descr_pref = $row3['descr'];
}
?>
<!DOCTYPE HTML>
<html>

<head>
	<title>View Profile - Shuvomilon</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap-3.1.1.min.css" rel="stylesheet" type="text/css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/font-awesome.css" rel="stylesheet">
</head>

<body>
	<?php include_once("includes/navigation.php"); ?>

	<div class="grid_3">
		<div class="container">
			<div class="breadcrumb1">
				<ul>
					<a href="index.php"><i class="fa fa-home home_1"></i></a>
					<span class="divider">&nbsp;|&nbsp;</span>
					<li class="current-page">View Profile</li>
				</ul>
			</div>
			<div class="profile">
				<div class="col-md-8 profile_left">
					<h2>Profile Id: <?php echo $profile_id; ?></h2>
					<div class="col_3">
						<div class="col-sm-4 row_2">
							<div class="flexslider">
								<ul class="slides">
									<li data-thumb="profile/<?php echo $profile_id; ?>/<?php echo $pic1; ?>">
										<img src="profile/<?php echo $profile_id; ?>/<?php echo $pic1; ?>" />
									</li>
									<li data-thumb="profile/<?php echo $profile_id; ?>/<?php echo $pic2; ?>">
										<img src="profile/<?php echo $profile_id; ?>/<?php echo $pic2; ?>" />
									</li>
									<li data-thumb="profile/<?php echo $profile_id; ?>/<?php echo $pic3; ?>">
										<img src="profile/<?php echo $profile_id; ?>/<?php echo $pic3; ?>" />
									</li>
									<li data-thumb="profile/<?php echo $profile_id; ?>/<?php echo $pic4; ?>">
										<img src="profile/<?php echo $profile_id; ?>/<?php echo $pic4; ?>" />
									</li>
								</ul>
							</div>
						</div>
						<div class="col-sm-8 row_1">
							<table class="table_working_hours">
								<tbody>
									<tr class="opened_1">
										<td class="day_label">Name :</td>
										<td class="day_value"><?php echo $fname . " " . $lname; ?></td>
									</tr>
									<tr class="opened">
										<td class="day_label">Age / Height :</td>
										<td class="day_value">
											<?php echo $age . " Years"; ?>/<?php echo $height . " Cm"; ?>
										</td>
									</tr>
									<tr class="opened">
										<td class="day_label">Religion :</td>
										<td class="day_value"><?php echo $religion; ?></td>
									</tr>
									<tr class="opened">
										<td class="day_label">Marital Status :</td>
										<td class="day_value"><?php echo $maritalstatus; ?></td>
									</tr>
									<tr class="opened">
										<td class="day_label">Country :</td>
										<td class="day_value"><?php echo $country; ?></td>
									</tr>
									<tr class="opened">
										<td class="day_label">Profile Created by :</td>
										<td class="day_value"><?php echo $profileby; ?></td>
									</tr>
								</tbody>
							</table>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
				<div class="col-md-4 profile_right">
					<div class="view_profile view_profile2">
						<h3>View Recent Profiles</h3>
						<?php
						$sql = "SELECT * FROM customer ORDER BY profilecreationdate DESC LIMIT 5";
						$result = mysqlexec($sql);
						while ($row = mysqli_fetch_assoc($result)) {
							$profid = $row['cust_id'];
							$sql2 = "SELECT * FROM photos WHERE cust_id = $profid";
							$result2 = mysqlexec($sql2);
							$photo = mysqli_fetch_assoc($result2);

							// Check if pic1 exists, otherwise use a default image
							$pic = isset($photo['pic1']) && !empty($photo['pic1']) ? $photo['pic1'] : 'default.jpg';

							echo "<ul class=\"profile_item\">";
							echo "<a href=\"view_profile.php?id={$profid}\">";
							echo "<li class=\"profile_item-img\"><img src=\"profile/{$profid}/{$pic}\" class=\"img-responsive\" alt=\"\"/></li>";
							echo "<li class=\"profile_item-desc\">";
							echo "<h4>" . $row['firstname'] . " " . $row['lastname'] . "</h4>";
							echo "<p>" . $row['age'] . " Yrs, " . $row['religion'] . "</p>";
							echo "<h5>View Full Profile</h5>";
							echo "</li>";
							echo "</a>";
							echo "</ul>";
						}
						?>

					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>

	<?php include_once("footer.php"); ?>
	<script defer src="js/jquery.flexslider.js"></script>
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
	<script>
		$(window).load(function () {
			$('.flexslider').flexslider({
				animation: "slide",
				controlNav: "thumbnails"
			});
		});
	</script>
</body>

</html>